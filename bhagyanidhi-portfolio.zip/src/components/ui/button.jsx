
export function Button({ children, variant = 'default' }) {
  const base = 'px-4 py-2 rounded-xl font-medium transition hover:opacity-80';
  const styles = variant === 'outline'
    ? 'border border-gray-300 dark:border-gray-600'
    : 'bg-blue-600 text-white';
  return <button className={`${base} ${styles}`}>{children}</button>;
}
